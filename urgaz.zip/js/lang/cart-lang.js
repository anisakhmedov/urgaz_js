let cartLang = {
    "inSaved": { //done
        "ru": "В избранном",
        "en": "In favorites",
        "uz": "Sevimlilar",
    },
}