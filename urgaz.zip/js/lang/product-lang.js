let productLang = {
    "prod-cat": {
        "ru": "Категория",
        "en": "Category",
        "uz": "Kategoriya"
    },
    "prod-vorse": {
        "ru": "Ворс",
        "en": "Pile",
        "uz": "Qopqoq"
    },
    "prod-weight": {
        "ru": "Вес",
        "en": "Weight",
        "uz": "Og'irligi",
    },
    "prod-puch": {
        "ru": "Количество пучков",
        "en": "Number of bundles",
        "uz": "To'plamlar soni"
    },
    "prod-save": {
        "ru": "Добавить в избранное",
        "en": "Add to Favorites",
        "uz": "Sevimlilarga qo'shish",
    },
    "prod-more": {
        "ru": "Остальные наши товары",
        "en": "The rest of our products",
        "uz": "Qolgan mahsulotlarimiz",
    },
}